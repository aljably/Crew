import 'package:flutter/material.dart';

class ScheduleScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الجدول')),
      body: ListView(
        children: [
          ListTile(title: Text('2025-04-01 - رحلة محددة')),
          ListTile(title: Text('2025-04-02 - انتظار صباحي')),
        ],
      ),
    );
  }
}