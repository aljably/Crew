import 'package:flutter/material.dart';

class ChangePasswordScreen extends StatelessWidget {
  final _oldPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تغيير كلمة المرور')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _oldPasswordController,
              decoration: InputDecoration(labelText: 'كلمة المرور الحالية'),
              obscureText: true,
            ),
            TextField(
              controller: _newPasswordController,
              decoration: InputDecoration(labelText: 'كلمة المرور الجديدة'),
              obscureText: true,
            ),
            TextField(
              controller: _confirmPasswordController,
              decoration: InputDecoration(labelText: 'تأكيد كلمة المرور الجديدة'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                if (_newPasswordController.text == _confirmPasswordController.text) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم تغيير كلمة المرور')));
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('كلمات المرور غير متطابقة')));
                }
              },
              child: Text('تأكيد'),
            )
          ],
        ),
      ),
    );
  }
}