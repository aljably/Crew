import 'package:flutter/material.dart';

class NewReportScreen extends StatelessWidget {
  final _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تقرير جديد')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _controller, maxLines: 5, decoration: InputDecoration(labelText: 'تفاصيل التقرير')),
            SizedBox(height: 20),
            ElevatedButton(onPressed: () {}, child: Text('إرسال')),
          ],
        ),
      ),
    );
  }
}