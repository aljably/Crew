import 'package:flutter/material.dart';

class EditProfileScreen extends StatelessWidget {
  final _name = TextEditingController(text: 'الاسم الحالي');
  final _email = TextEditingController(text: 'example@mail.com');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تعديل الحساب')),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(controller: _name, decoration: InputDecoration(labelText: 'الاسم')),
            TextField(controller: _email, decoration: InputDecoration(labelText: 'البريد الإلكتروني')),
            ElevatedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تم التحديث')));
              },
              child: Text('حفظ'),
            )
          ],
        ),
      ),
    );
  }
}