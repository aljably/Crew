import 'package:flutter/material.dart';

class ReportsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('التقارير'),
      ),
      body: ListView(
        children: [
          ListTile(
            leading: Icon(Icons.assignment),
            title: Text('تقرير رحلة 2025-04-01'),
            subtitle: Text('تم إرسال التقرير بنجاح'),
            onTap: () {
              // هنا يمكن أن تنتقل إلى شاشة تفاصيل التقرير
            },
          ),
          ListTile(
            leading: Icon(Icons.assignment),
            title: Text('تقرير رحلة 2025-04-02'),
            subtitle: Text('بانتظار المراجعة'),
            onTap: () {
              // هنا يمكن أن تنتقل إلى شاشة تفاصيل التقرير
            },
          ),
          ListTile(
            leading: Icon(Icons.assignment),
            title: Text('تقرير رحلة 2025-04-03'),
            subtitle: Text('مقبول'),
            onTap: () {
              // هنا يمكن أن تنتقل إلى شاشة تفاصيل التقرير
            },
          ),
        ],
      ),
    );
  }
}