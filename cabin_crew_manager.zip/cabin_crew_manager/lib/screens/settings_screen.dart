import 'package:flutter/material.dart';
import '../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _darkMode = false;

  @override
  void initState() {
    super.initState();
    SettingsService.isDarkMode().then((val) => setState(() => _darkMode = val));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('الإعدادات')),
      body: SwitchListTile(
        title: Text('الوضع الداكن'),
        value: _darkMode,
        onChanged: (val) {
          setState(() => _darkMode = val);
          SettingsService.saveThemeMode(val);
        },
      ),
    );
  }
}