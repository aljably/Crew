import 'package:flutter/material.dart';
import '../services/backup_service.dart';

class BackupScreen extends StatelessWidget {
  final _backupService = BackupService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('النسخ الاحتياطي')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () async {
                await _backupService.createBackup({'data': 'backup'});
              },
              child: Text('إنشاء نسخة احتياطية'),
            ),
            ElevatedButton(
              onPressed: () async {
                final restored = await _backupService.restoreBackup();
                print(restored);
              },
              child: Text('استعادة النسخة'),
            ),
          ],
        ),
      ),
    );
  }
}