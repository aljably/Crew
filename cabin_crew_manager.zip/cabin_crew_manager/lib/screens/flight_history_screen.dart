import 'package:flutter/material.dart';

class FlightHistoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('سجل الرحلات')),
      body: ListView(
        children: [
          ListTile(title: Text('2025-03-20 - صنعاء - عدن')),
          ListTile(title: Text('2025-03-23 - عدن - القاهرة')),
        ],
      ),
    );
  }
}