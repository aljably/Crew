import 'package:flutter/material.dart';

class EvaluationScreen extends StatelessWidget {
  final Map<String, int> scores = {
    'الالتزام': 4,
    'الدقة': 5,
    'التعاون': 3,
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تقييم الأداء')),
      body: ListView(
        children: scores.entries.map((e) => ListTile(
          title: Text(e.key),
          trailing: Text('${e.value}/5'),
        )).toList(),
      ),
    );
  }
}