import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class ReportNotificationService {
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    await _plugin.initialize(
      InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
    );
  }

  Future<void> showNotification(String title, String body) async {
    await _plugin.show(
      1,
      title,
      body,
      NotificationDetails(
        android: AndroidNotificationDetails('report_channel', 'تنبيهات التقارير'),
      ),
    );
  }
}