import 'package:flutter/services.dart';

class NativeBridge {
  static const platform = MethodChannel('crew/native');

  static Future<void> showNativeNotification(String title, String body) async {
    try {
      await platform.invokeMethod('showNotification', {
        'title': title,
        'body': body,
      });
    } catch (e) {
      print('Error: $e');
    }
  }
}