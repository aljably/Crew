class AuthService {
  static Future<bool> login(String email, String password) async {
    return email == 'admin@app.com' && password == '123456';
  }

  static Future<void> logout() async {
    print('تم تسجيل الخروج');
  }
}