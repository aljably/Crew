import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class BackupService {
  Future<String> _getFilePath() async {
    final dir = await getApplicationDocumentsDirectory();
    return '${dir.path}/backup.json';
  }

  Future<void> createBackup(Map<String, dynamic> data) async {
    final path = await _getFilePath();
    final file = File(path);
    await file.writeAsString(jsonEncode(data));
  }

  Future<Map<String, dynamic>?> restoreBackup() async {
    final path = await _getFilePath();
    final file = File(path);
    if (!await file.exists()) return null;
    final contents = await file.readAsString();
    return jsonDecode(contents);
  }
}