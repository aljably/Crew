import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LogoutButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      icon: Icon(Icons.logout),
      label: Text('تسجيل الخروج'),
      onPressed: () async {
        await AuthService.logout();
        Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
      },
    );
  }
}